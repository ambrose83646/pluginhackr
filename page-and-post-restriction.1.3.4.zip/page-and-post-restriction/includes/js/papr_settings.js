jQuery(document).ready(function() {
    jQuery("#contact_us_phone").intlTelInput();
});